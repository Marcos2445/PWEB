var express = require('express');var app=express(); // executando o expressapp.set('view engine', 'ejs'); // o mecanismo de engine a ser usadoapp.set('views','./app/views'); //  diretório onde os arquivos  estão localizadosmodule.exports = app;

