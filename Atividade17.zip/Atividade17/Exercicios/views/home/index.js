<!DOCTYPE html>

<html lang="pt-br">

<head>

    <meta charset="UTF-8">

    <title> Pagina principal</title>

</head>

<body>

   <ul> Os cursos da Fatec Sorocaba são:

   <li>Análise e Desenvolvimento de Sistemas</li>

  <li> Eletrônica Automotiva</li>

   <li>Fabricação Mecânica</li>

   <li>Gestão da Qualidade</li>

  <li> Logística</li>

   <li>Manufatura Avançada</li>

   <li>Processos Metalúrgicos</li>

  <li> Polímeros</li>

   <li>Projetos Mecânicos</li>

   <li>Sistemas Biomédicos</li>

  <li> Gestão Empresarial - EAD</li>

</ul>

</body>

</html>